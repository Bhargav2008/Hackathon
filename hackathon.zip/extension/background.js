chrome.runtime.onInstalled.addListener(() => {
    console.log("Fake News Detector extension installed!");
});